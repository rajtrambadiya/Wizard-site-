function section1() {
    var tl = gsap.timeline()

tl.from(".navlogo h2, .navmenu h4, .btn",{
    y:-30,
    opacity:0,
    duration:0.5,
    delay:0.5,
    stagger:0.15,
    scrub:2
})
tl.from(".note h2",{
    x:-500,
    opacity:0,
    duration:0.7,
    
})
tl.from(".note p",{
    x:-500,
    opacity:0,
    duration:0.7,
})
tl.from(".note .btn2",{
    opacity:0,
    duration:1,
})
tl.from(".image",{
    opacity:0,
    duration:1.5,
    scrub:2
},"-=2.1")
tl.from(".compneys img",{
    y:30,
    opacity:0,
    duration:0.7,
    stagger:0.15,
    scrub:2
})
}
section1()

function section2() {
    var tl2 = gsap.timeline({
        scrollTrigger:{
            trigger:"section2",
            scroller:"body",
            start:"top 60%",
            end:"top 0%",
            scrub:2
        }
    })
    tl2.from(".services h2 , .services p",{
        y:30,
        opacity:0
    })
    tl2.from("#lineone-lift",{
        x:-300,
        opacity:0,
        duration:1
    },"anime")
    tl2.from("#lineone-right",{
        x:300,
        opacity:0,
        duration:1
    },"anime")
    tl2.from("#lineTwo-lift",{
        x:-300,
        opacity:0,
        duration:1
    },"anime1")
    tl2.from("#lineTwo-right",{
        x:300,
        opacity:0,
        duration:1
    },"anime1")
}
section2()

function section3() {
    var tl3 = gsap.timeline({
        scrollTrigger:{
            trigger:"section3",
            scroller:"body",
            start:"top 65%",
            end:"top 0%",
            scrub:2
        }
    })
    tl3.from(".box",{
        opacity:0,
        duration:1
    },"box")
    tl3.from(".write h2 , .write p , .write .btn3",{
        opacity:0,
        duration:1
    },"box")
    tl3.from("#service1 h2 #service1 p",{
        y:-30,
        opacity:0,
        duration:1
    })
}
section3()

